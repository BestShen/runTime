//
//  main.m
//  001--runtime初体验
//
//  Created by H on 16/5/22.
//  Copyright © 2016年 TanZhou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, @"UIApplication", NSStringFromClass([AppDelegate class]));
    }
}
