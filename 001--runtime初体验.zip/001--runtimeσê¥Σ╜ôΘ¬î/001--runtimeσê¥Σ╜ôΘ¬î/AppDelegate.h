//
//  AppDelegate.h
//  001--runtime初体验
//
//  Created by H on 16/5/22.
//  Copyright © 2016年 TanZhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

