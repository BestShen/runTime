//
//  HKPerson.h
//  001--runtime初体验
//
//  Created by H on 16/5/22.
//  Copyright © 2016年 TanZhou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HKPerson : NSObject
/** 名称 */
@property(copy,nonatomic)NSString * name;
/** 年龄 */
@property(assign,nonatomic)NSInteger age;
@property(assign,nonatomic)NSInteger age1;
@property(assign,nonatomic)NSInteger age2;
@property(assign,nonatomic)NSInteger age3;
@property(assign,nonatomic)NSInteger age4;
//@property(assign,nonatomic)NSInteger age5;
//@property(assign,nonatomic)NSInteger age6;
//@property(assign,nonatomic)NSInteger age7;
//@property(assign,nonatomic)NSInteger age8;
//....
//age 100

@end
